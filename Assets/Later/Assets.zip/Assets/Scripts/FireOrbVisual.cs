
using UnityEngine;

public enum OrbVisualState
{
    Orbiting,
    Scheduled,
    Charging,
    Arrived,
    PendingExplosion,
    Deflected,
    Exploded
}

public class FireOrbVisual : MonoBehaviour
{
    [Header("Visual Effects")]
    public GameObject explosionPrefab;

    [Header("Movement Settings")]
    public float orbitSpeed = 150f;
    public float deflectSpeed = 20f;
    public float arrivalDistance = 0.05f;
    public float deflectDistance = 30f;

    private VisualBossController bossController;
    private Transform orbitCenter;

    private OrbVisualState currentState = OrbVisualState.Orbiting;

    private Vector3 orbitOffset;
    private Vector3 targetPosition;
    private Vector3 travelDirection;
    private Vector3 deflectDirection;
    private Vector3 deflectStartPosition;

    private float travelSpeed;
    private float scheduledLaunchTime;
    private float explosionTime;

    private bool launchScheduled;

    public bool CanBeInteractedWith
    {
        get
        {
            return currentState == OrbVisualState.Charging ||
                   currentState == OrbVisualState.Arrived;
        }
    }

    public void Initialize(
        VisualBossController boss,
        Transform center,
        Vector3 initialOffset,
        float speed
    )
    {
        bossController = boss;
        orbitCenter = center;
        orbitOffset = initialOffset;
        travelSpeed = Mathf.Max(speed, 0.01f);

        currentState = OrbVisualState.Orbiting;
        launchScheduled = false;
    }

    private void Update()
    {
        switch (currentState)
        {
            case OrbVisualState.Orbiting:
                HandleOrbit();
                break;

            case OrbVisualState.Charging:
            case OrbVisualState.PendingExplosion:
                HandleCharge();

                if (currentState == OrbVisualState.PendingExplosion &&
                    Time.time >= explosionTime)
                {
                    VisualExplodeNow();
                }
                break;

            case OrbVisualState.Deflected:
                HandleDeflect();
                break;
        }
    }

    private void HandleOrbit()
    {
        if (orbitCenter == null)
            return;

        orbitOffset = Quaternion.AngleAxis(
            orbitSpeed * Time.deltaTime,
            Vector3.up
        ) * orbitOffset;

        transform.position = orbitCenter.position + orbitOffset;
    }

    public void StopOrbiting()
    {
        if (currentState == OrbVisualState.Orbiting)
            currentState = OrbVisualState.Scheduled;
    }

    public void ScheduleLaunch(Vector3 target, float launchTime)
    {
        if (currentState != OrbVisualState.Scheduled)
            return;

        targetPosition = target;
        scheduledLaunchTime = launchTime;
        launchScheduled = true;
    }

    public void UpdateScheduledLaunch(float elapsedTime)
    {
        if (currentState != OrbVisualState.Scheduled ||
            !launchScheduled)
            return;

        if (elapsedTime >= scheduledLaunchTime)
        {
            launchScheduled = false;
            currentState = OrbVisualState.Charging;
        }
    }

    private void HandleCharge()
    {
        MoveTowards(targetPosition);

        if (Vector3.Distance(transform.position, targetPosition)
            <= arrivalDistance)
        {
            transform.position = targetPosition;

            if (currentState == OrbVisualState.Charging)
                currentState = OrbVisualState.Arrived;
        }
    }

    private void MoveTowards(Vector3 destination)
    {
        Vector3 direction = destination - transform.position;

        if (direction.sqrMagnitude > 0.0001f)
        {
            travelDirection = direction.normalized;
            transform.rotation = Quaternion.LookRotation(travelDirection);
        }

        transform.position = Vector3.MoveTowards(
            transform.position,
            destination,
            travelSpeed * Time.deltaTime
        );
    }

    public void VisualDeflect()
    {
        if (!CanBeInteractedWith)
            return;

        Vector3 randomOffset = new Vector3(
            Random.Range(-1f, 1f),
            Random.Range(0.2f, 1f),
            Random.Range(-1f, 1f)
        );

        deflectDirection =
            (-travelDirection + randomOffset).normalized;

        if (deflectDirection.sqrMagnitude < 0.001f)
            deflectDirection = Vector3.up;

        deflectStartPosition = transform.position;
        currentState = OrbVisualState.Deflected;
    }

    private void HandleDeflect()
    {
        transform.position +=
            deflectDirection * deflectSpeed * Time.deltaTime;

        if (Vector3.Distance(
            deflectStartPosition,
            transform.position
        ) >= deflectDistance)
        {
            Destroy(gameObject);
        }
    }

    // Begin a delayed explosion.
    public void ScheduleExplosion(float delay)
    {
        if (!CanBeInteractedWith)
            return;

        currentState = OrbVisualState.PendingExplosion;
        explosionTime = Time.time + Mathf.Max(0f, delay);
    }

    // Immediately create the explosion effect and remove the orb.
    private void VisualExplodeNow()
    {
        if (currentState == OrbVisualState.Exploded)
            return;

        currentState = OrbVisualState.Exploded;

        if (explosionPrefab != null)
        {
            Instantiate(
                explosionPrefab,
                transform.position,
                Quaternion.identity
            );
        }

        Destroy(gameObject);
    }

    // Used for immediate cleanup when the player dies.
    public void RemoveImmediately()
    {
        currentState = OrbVisualState.Exploded;
        Destroy(gameObject);
    }
}
