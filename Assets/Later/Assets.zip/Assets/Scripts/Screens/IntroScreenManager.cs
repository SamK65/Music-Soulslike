using UnityEngine;

public class IntroScreenManager : MonoBehaviour
{
    public static IntroScreenManager Instance { get; private set; }

    [SerializeField] public GameObject IntroScreen;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void IntroScreenSet()
    {
        IntroScreen.SetActive(true);
    }

    public void IntroScreenClear()
    {
        IntroScreen.SetActive(false);
    }
}
