using UnityEngine;

public class DefeatScreenManager : MonoBehaviour
{
    public static DefeatScreenManager Instance { get; private set; }

    [SerializeField] public GameObject DefeatScreen;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void DefeatScreenSet()
    {
        DefeatScreen.SetActive(true);
    }

    public void DefeatScreenClear()
    {
        DefeatScreen.SetActive(false);
    }
}
