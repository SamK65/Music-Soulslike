using UnityEngine;

public class HighScoreScreenManager : MonoBehaviour
{
    public static HighScoreScreenManager Instance { get; private set; }

    [SerializeField] public GameObject HighScoreScreen;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void HighScoreScreenSet()
    {
        HighScoreScreen.SetActive(true);
    }

    public void HighScoreScreenClear()
    {
        HighScoreScreen.SetActive(false);
    }
}
