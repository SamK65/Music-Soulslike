using UnityEngine;

public class VictoryScreenManager : MonoBehaviour
{
    public static VictoryScreenManager Instance { get; private set; }

    [SerializeField] public GameObject VictoryScreen;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void VictoryScreenSet()
    {
        VictoryScreen.SetActive(true);
    }

    public void VictoryScreenClear()
    {
        VictoryScreen.SetActive(false);
    }
}
