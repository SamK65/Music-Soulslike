using UnityEngine;

public class PauseScreenManager : MonoBehaviour
{
    public static PauseScreenManager Instance { get; private set; }

    [SerializeField] public GameObject PauseScreen;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void PauseScreenSet()
    {
        PauseScreen.SetActive(true);
    }

    public void PauseScreenClear()
    {
        PauseScreen.SetActive(false);
    }
}
