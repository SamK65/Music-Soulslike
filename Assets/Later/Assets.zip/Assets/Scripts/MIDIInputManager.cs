
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class MIDIInputManager : MonoBehaviour
{
    [SerializeField]
    private VirtualKeyController virtualKeyController;

    private readonly List<Minis.MidiDevice> midiDevices = new();

    public bool MIDIConnected => midiDevices.Count > 0;

    private bool debug = true;

    private void OnEnable()
    {
        Debugger("[MIDI] Manager enabled.");

        InputSystem.onDeviceChange += OnDeviceChange;

        RefreshDevices();
    }

    private void OnDisable()
    {
        InputSystem.onDeviceChange -= OnDeviceChange;

        DisconnectAllDevices();
    }

    private void OnDeviceChange(
        InputDevice device,
        InputDeviceChange change)
    {
        Debugger(
            $"[MIDI] Device change: {device.name} | {change}"
        );

        // Rebuild subscriptions from all currently registered devices.
        RefreshDevices();
    }

    private void RefreshDevices()
    {
        DisconnectAllDevices();

        foreach (InputDevice device in InputSystem.devices)
        {
            Minis.MidiDevice midiDevice =
                device as Minis.MidiDevice;

            if (midiDevice == null)
                continue;

            Debugger(
                $"[MIDI] Registering: {midiDevice.description.product} " +
                $"Channel {midiDevice.channel}"
            );

            midiDevice.onWillNoteOn += OnMidiNoteOn;
            midiDevice.onWillNoteOff += OnMidiNoteOff;
            midiDevice.onWillControlChange += OnMidiControlChange;

            midiDevices.Add(midiDevice);
        }

        Debugger(
            $"[MIDI] Active MIDI devices: {midiDevices.Count}"
        );
    }

    private void DisconnectAllDevices()
    {
        foreach (Minis.MidiDevice device in midiDevices)
        {
            device.onWillNoteOn -= OnMidiNoteOn;
            device.onWillNoteOff -= OnMidiNoteOff;
            device.onWillControlChange -= OnMidiControlChange;
        }

        midiDevices.Clear();
    }

    private void OnMidiNoteOn(
        Minis.MidiNoteControl note,
        float velocity)
    {
        int midiVelocity = Mathf.RoundToInt(velocity * 127f);

        Debugger(
            $"[MIDI] NOTE ON | " +
            $"Note: {note.noteNumber} | " +
            $"Velocity: {midiVelocity} | " +
            $"Channel: {note.channel}"
        );

        if (virtualKeyController != null)
        {
            virtualKeyController.OnMidiNoteOn(
                note.noteNumber,
                midiVelocity
            );
        }
    }

    private void OnMidiNoteOff(Minis.MidiNoteControl note)
    {
        Debugger(
            $"[MIDI] NOTE OFF | " +
            $"Note: {note.noteNumber} | " +
            $"Channel: {note.channel}"
        );

        if (virtualKeyController != null)
        {
            virtualKeyController.OnMidiNoteOff(
                note.noteNumber
            );
        }
    }

    private void OnMidiControlChange(
        Minis.MidiValueControl control,
        float value)
    {
        Debugger(
            $"[MIDI] CONTROL CHANGE | " +
            $"CC: {control.controlNumber} | " +
            $"Value: {value:F3} | " +
            $"Channel: {control.channel}"
        );
    }

    private void Debugger(string info)
    {
        if (debug)
            Debug.Log(info);
    }
}
