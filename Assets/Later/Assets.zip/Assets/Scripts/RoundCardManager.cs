using UnityEngine;
using TMPro;

public class RoundCardManager : MonoBehaviour
{
    public static RoundCardManager Instance { get; private set; }

    [SerializeField] public GameObject RoundCardText;

    [Header("Round Card")]
    [SerializeField] private TextMeshProUGUI uiText; 

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void RoundCardSet(int Boss, int Round)
    {
        uiText.SetText($"Round\n{Boss}");
        RoundCardText.SetActive(true);
    }

    public void RoundCardClear()
    {
        RoundCardText.SetActive(false);
    }
}
