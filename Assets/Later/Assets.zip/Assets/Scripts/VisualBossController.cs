
using System.Collections.Generic;
using UnityEngine;

public class VisualBossController : MonoBehaviour
{
    [Header("Prefabs")]
    public GameObject fireOrbPrefab;
    public GameObject bossDeathExplosionPrefab;

    [Header("References")]
    public Transform orbOrbitCenter;
    public Transform playerTransform;

    [Header("Orb Settings")]
    public int orbCount = 4;
    public float orbitRadius = 25f;
    public float orbTravelSpeed = 12f;

    [Header("Musical Timing")]
    public float bpm = 120f;
    public float beatsBetweenArrivals = 1f;
    [Range(-1f, 1f)]
    public float initialArrivalOffsetBeats = 0.5f;

    [Header("Boss Death Explosion")]
    public Transform bossDeathExplosionPoint;
    public Vector3 bossExplosionPositionOffset;
    public Vector3 bossExplosionRotationOffset;
    public Vector3 bossExplosionScale = Vector3.one;

    private List<FireOrbVisual> activeOrbs =
        new List<FireOrbVisual>();

    private bool attackSequenceActive;
    private float attackSequenceStartTime;

    public void SpawnVisualOrbs()
    {
        if (fireOrbPrefab == null ||
            orbOrbitCenter == null ||
            playerTransform == null)
        {
            Debug.LogError("Missing orb controller references!", this);
            return;
        }

        ClearRemainingOrbs();

        if (orbCount <= 0)
            return;

        for (int i = 0; i < orbCount; i++)
        {
            float angle = i * Mathf.PI * 2f / orbCount;

            Vector3 offset = new Vector3(
                Mathf.Cos(angle) * orbitRadius,
                0f,
                Mathf.Sin(angle) * orbitRadius
            );

            GameObject orbObject = Instantiate(
                fireOrbPrefab,
                orbOrbitCenter.position + offset,
                Quaternion.identity
            );

            FireOrbVisual orb =
                orbObject.GetComponent<FireOrbVisual>();

            if (orb == null)
            {
                Debug.LogError(
                    "FireOrbVisual component missing!",
                    orbObject
                );

                Destroy(orbObject);
                continue;
            }

            orb.Initialize(
                this,
                orbOrbitCenter,
                offset,
                orbTravelSpeed
            );

            activeOrbs.Add(orb);
        }
    }

    // ANIMATION EVENT: Release orbs.
    public void LaunchVisualOrbs()
    {
        if (attackSequenceActive || activeOrbs.Count == 0)
            return;

        if (playerTransform == null)
            return;

        attackSequenceActive = true;
        attackSequenceStartTime = Time.time;

        Vector3 targetPosition = playerTransform.position;

        float longestTravelTime = 0f;

        foreach (FireOrbVisual orb in activeOrbs)
        {
            if (orb == null)
                continue;

            orb.StopOrbiting();

            float travelTime = Vector3.Distance(
                orb.transform.position,
                targetPosition
            ) / Mathf.Max(orbTravelSpeed, 0.01f);

            longestTravelTime = Mathf.Max(
                longestTravelTime,
                travelTime
            );
        }

        float arrivalInterval =
            (60f / Mathf.Max(bpm, 0.01f)) *
            Mathf.Max(beatsBetweenArrivals, 0.01f);

        int validOrbIndex = 0;

        float beatDuration = 60f / Mathf.Max(bpm, 0.01f);
        float initialOffset = beatDuration * initialArrivalOffsetBeats;

        foreach (FireOrbVisual orb in activeOrbs) {
            if (orb == null)
                continue;
            float travelTime = Vector3.Distance(orb.transform.position, targetPosition) / Mathf.Max(orbTravelSpeed, 0.01f);

            // Only the first orb receives the adjustable offset.
            float scheduledArrival = longestTravelTime + validOrbIndex * arrivalInterval;

            if (validOrbIndex == 0)
                scheduledArrival -= initialOffset;

            // Calculate when this orb must begin moving.
            float scheduledLaunch = Mathf.Max(0f,scheduledArrival - travelTime);

            orb.ScheduleLaunch(
                targetPosition,
                scheduledLaunch
            );

            validOrbIndex++;
        }
    }

    private void Update()
    {
        if (!attackSequenceActive)
            return;

        float elapsedTime = Time.time - attackSequenceStartTime;

        foreach (FireOrbVisual orb in activeOrbs)
        {
            if (orb != null)
                orb.UpdateScheduledLaunch(elapsedTime);
        }
    }

    private FireOrbVisual FindNearestEligibleOrb()
    {
        FireOrbVisual nearestOrb = null;
        float closestDistance = float.MaxValue;

        if (playerTransform == null)
            return null;

        foreach (FireOrbVisual orb in activeOrbs)
        {
            if (orb == null || !orb.CanBeInteractedWith)
                continue;

            float distance = Vector3.Distance(
                playerTransform.position,
                orb.transform.position
            );

            if (distance < closestDistance)
            {
                closestDistance = distance;
                nearestOrb = orb;
            }
        }

        return nearestOrb;
    }

    // Player deflection animation event.
    public bool DeflectNearestOrb()
    {
        FireOrbVisual orb = FindNearestEligibleOrb();

        if (orb == null)
            return false;

        orb.VisualDeflect();
        return true;
    }

    // Player hit animation event.
    // The orb continues moving for one beat before exploding.
    public bool ExplodeNearestOrb()
    {
        FireOrbVisual orb = FindNearestEligibleOrb();

        if (orb == null)
            return false;

        float oneBeatDuration = 60f / Mathf.Max(bpm, 0.01f);

        orb.ScheduleExplosion(oneBeatDuration);

        return true;
    }

    // PLAYER DEATH ANIMATION EVENT:
    // Immediately remove every remaining orb.
    public void ClearRemainingOrbs()
    {
        attackSequenceActive = false;

        foreach (FireOrbVisual orb in activeOrbs)
        {
            if (orb != null)
                orb.RemoveImmediately();
        }

        activeOrbs.Clear();
    }

    // BOSS DEATH ANIMATION EVENT.
    public void TriggerBossDeathExplosion()
    {
        if (bossDeathExplosionPrefab == null)
        {
            Debug.LogWarning(
                "Boss death explosion prefab is missing!",
                this
            );
            return;
        }

        Vector3 spawnPosition;
        Quaternion spawnRotation;

        if (bossDeathExplosionPoint != null)
        {
            spawnPosition = bossDeathExplosionPoint.position +
                bossDeathExplosionPoint.TransformVector(
                    bossExplosionPositionOffset
                );

            spawnRotation = bossDeathExplosionPoint.rotation *
                Quaternion.Euler(bossExplosionRotationOffset);
        }
        else
        {
            spawnPosition = transform.position +
                transform.TransformVector(bossExplosionPositionOffset);

            spawnRotation = transform.rotation *
                Quaternion.Euler(bossExplosionRotationOffset);
        }

        GameObject explosion = Instantiate(
            bossDeathExplosionPrefab,
            spawnPosition,
            spawnRotation
        );

        explosion.transform.localScale = Vector3.Scale(
            explosion.transform.localScale,
            bossExplosionScale
        );
    }
}
