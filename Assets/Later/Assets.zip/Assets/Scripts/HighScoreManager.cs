
using System;
using UnityEngine;

public static class HighScoreManager
{
    private const string SaveKey = "Game_HighScore";

    [Serializable]
    public class HighScoreEntry
    {
        public string initials;
        public int score;

        public HighScoreEntry(string initials, int score)
        {
            this.initials = initials;
            this.score = score;
        }
    }

    private static HighScoreEntry highScore;

    // Load high score when first requested.
    private static void EnsureLoaded()
    {
        if (highScore != null)
            return;

        string json = PlayerPrefs.GetString(SaveKey, "");

        if (!string.IsNullOrEmpty(json))
        {
            try
            {
                highScore = JsonUtility.FromJson<HighScoreEntry>(json);
            }
            catch (Exception e)
            {
                Debug.LogWarning($"Could not load high score: {e.Message}");
            }
        }

        if (highScore == null || highScore.score < 0)
        {
            highScore = new HighScoreEntry("AAA", 0);
        }

        highScore.initials = NormalizeInitials(highScore.initials);
    }

    private static string NormalizeInitials(string initials)
    {
        if (string.IsNullOrWhiteSpace(initials))
            return "AAA";

        initials = initials.Trim().ToUpperInvariant();

        if (initials.Length > 3)
            initials = initials.Substring(0, 3);

        return initials.PadRight(3, 'A');
    }

    // Retrieve the current high score.
    public static HighScoreEntry GetHighScore()
    {
        EnsureLoaded();
        return highScore;
    }

    // Submit a score. Returns true if it becomes the new high score.
    public static bool SubmitScore(int score, string initials)
    {
        EnsureLoaded();

        if (score <= highScore.score)
            return false;

        initials = NormalizeInitials(initials);

        highScore = new HighScoreEntry(initials, score);

        SaveHighScore();

        return true;
    }

    private static void SaveHighScore()
    {
        string json = JsonUtility.ToJson(highScore);

        PlayerPrefs.SetString(SaveKey, json);
        PlayerPrefs.Save();
    }

    public static void WipeHighScore()
    {

        highScore = new HighScoreEntry("XXX", 0);
        
        string json = JsonUtility.ToJson(highScore);

        PlayerPrefs.SetString(SaveKey, json);
        PlayerPrefs.Save();
    }
}
