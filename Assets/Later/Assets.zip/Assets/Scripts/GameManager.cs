
using System;
using System.Collections;
using System.Reflection.Metadata;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SocialPlatforms.Impl;

public class GameManager : MonoBehaviour
{
    [SerializeField] private ChallengeManager challengeManager;
    
    // Graphics and Sound Control
    [SerializeField] private PdMessageRouter pdRouter;
    [SerializeField] private GraphicRouter graphicRouter;
    
    // Key Control
    [SerializeField] private VirtualKeyController virtualKeyController;

    public enum GameState
    {
        StartScreen,
        TutorialMode,
        InfiniteMode,
        ResetMode,
        GodMode,
        HighScore
    }

    public GameState CurrentState { get; private set; }

    public bool IsPaused { get; private set; }

    private bool introScreenSet = false;

    private bool scoreSubmitted = true;

    private HighScoreManager.HighScoreEntry highScore;

    private void Awake()
    {
        if (pdRouter == null)
            pdRouter = GetComponent<PdMessageRouter>();

        if (graphicRouter == null)
            graphicRouter = GetComponent<GraphicRouter>();
        
        // The game always boots to the start screen
        CurrentState = GameState.StartScreen;
        Time.timeScale = 1f;

        GameData.GodMode = false;

        Debug.Log("Game booted. Waiting for player selection.");
    }

    private void OnEnable()
    {
        if (virtualKeyController != null)
            virtualKeyController.OnNotePressed += HandleNotePressed;
    }

    private void OnDisable()
    {
        if (virtualKeyController != null)
            virtualKeyController.OnNotePressed -= HandleNotePressed;
    }

    private void HandleNotePressed(int degree)
    {
        // Only accept mode selection on the start screen.
        if (CurrentState == GameState.StartScreen)
        {
            if (degree == 1)
            {
                StartGame(GameState.TutorialMode);
            }
            else if (degree == 2)
            {
                StartGame(GameState.InfiniteMode);
            }
        }

        if (CurrentState != GameState.StartScreen
            && CurrentState != GameState.HighScore)
        {
            if (degree == 9) //Esc
            {
                TogglePause();
            }
            else if (degree == 8 && IsPaused) //Quit
            {
                GameData.Active = false;
                
                StopAllCoroutines();

                if (challengeManager != null)
                challengeManager.CancelChallenges();

                TogglePause();

                StartGame(GameState.StartScreen);
            }
        }

        if (CurrentState == GameState.HighScore)
        {
            if (degree == 9) //Esc
            {
                scoreSubmitted = true;
                Debug.Log($"scoreSubmitted: {scoreSubmitted}");
            }
        }
    }

    private void Update()
    {
        if (Keyboard.current == null)
            return;


        // Don't process start-screen shortcuts while already in a game.
        if (CurrentState != GameState.StartScreen)
            return;

        // Reset high score shortcut.
        if (Keyboard.current.zKey.wasPressedThisFrame &&
            Keyboard.current.altKey.isPressed &&
            Keyboard.current.shiftKey.isPressed)
        {
            StartGame(GameState.ResetMode);
        }
        // Reset high score shortcut.
        if (Keyboard.current.yKey.wasPressedThisFrame &&
            Keyboard.current.altKey.isPressed &&
            Keyboard.current.shiftKey.isPressed)
        {
            StartGame(GameState.GodMode);
        }
        
        if (CurrentState == GameState.StartScreen)
        {
            StartGame(GameState.StartScreen);
        }
    }

    private void StartGame(GameState selectedMode)
    {
        // Change the current state
        CurrentState = selectedMode;

        UpdateHighScore();

        // Dispatch to the selected mode
        switch (CurrentState)
        {
            case GameState.StartScreen:

                //Debug.Log("Starting Screen.");
                
                // Set Start Screen
                if (!introScreenSet && graphicRouter != null)
                {
                    graphicRouter.IntroScreenSet();
                    introScreenSet = true;
                }
                break;

            case GameState.TutorialMode:

                // Clear Start Screen
                if (graphicRouter != null)
                {
                    graphicRouter.IntroScreenClear();
                    introScreenSet = false;
                }
                Debug.Log("Tutorial Game Mode selected.");
                break;

            case GameState.InfiniteMode:
                // Initialize the session to to the selected mode
                
                GameData.InitializeSession(infiniteMode: selectedMode == GameState.InfiniteMode);

                Debug.Log("Infinite Game Mode selected.");

                // Clear Start Screen
                if (graphicRouter != null)
                {
                    graphicRouter.IntroScreenClear();
                    introScreenSet = false;
                }

                // Start Infinite Mode Loop
                if (challengeManager != null)
                {
                    StartCoroutine(InfiniteModeLoop());
                }
                else
                {
                    Debug.LogError(
                        "GameManager has no ChallengeManager assigned.");
                }

                break;
            case GameState.ResetMode:
                Debug.Log("Reseting.");
                HighScoreManager.WipeHighScore();
                StartGame(GameState.StartScreen);
                break;
            
            case GameState.GodMode:
                GameData.GodMode = true;
                StartGame(GameState.StartScreen);
                break;

            case GameState.HighScore:
                
                //StartCoroutine(HighScoreModeLoop());

                StartGame(GameState.StartScreen);

                break;
        }
    }

    private IEnumerator InfiniteModeLoop()
    {
        // Set emergency stop flag
        GameData.Active = true;
        
        while (CurrentState == GameState.InfiniteMode)
        {
            yield return new WaitForSeconds(2);

            // Run an entire boss encounter.
            yield return StartCoroutine(
                challengeManager.StartChallenges()
            );

            if (!GameData.Active)
            {
                yield break;
            }

            // Determine why the encounter ended.
            // GAME OVER
            if (challengeManager.CurrentState == ChallengeManager.ChallengeState.GameOver)
            {
                Debug.Log("GAME OVER");

                yield return new WaitForSeconds(3.5f);

                // Handle game-over conditions here.

                highScore = HighScoreManager.GetHighScore();

                // Check if they received the High Score
                if (GameData.Score > highScore.score)
                {
                    StartGame(GameState.HighScore);
                }
                else
                {
                    // Set Defeat Screen
                    if (graphicRouter != null)
                    {
                        graphicRouter.DefeatScreenSet();
                    }

                    yield return new WaitForSeconds(2);

                    // Clear Defeat Screen
                    if (graphicRouter != null)
                    {
                        graphicRouter.DefeatScreenClear();
                    }
                }

                StartGame(GameState.StartScreen);
                
                yield break;
            }

            // BOSS DEFEATED -> Next round
            if (challengeManager.CurrentState == ChallengeManager.ChallengeState.BossDefeated)
            {
                Debug.Log("BOSS DEFEATED");

                yield return new WaitForSeconds(8);
                // Start the next boss encounter.
            }
        }
    }

    // TODO FIX THIS SHIT
    private IEnumerator HighScoreModeLoop()
    {
        // Set High Score Screen
        if (graphicRouter != null)
        {
            graphicRouter.HighScoreScreenSet();
        }

        scoreSubmitted = false;

        yield return new WaitUntil(() => scoreSubmitted);

        Debug.Log($"POST WAIT scoreSubmitted: {scoreSubmitted}");

        // TODO: PROMPT FOR INITIALS
        HighScoreManager.SubmitScore(GameData.Score, "AAA");

        if (graphicRouter != null)
            graphicRouter.HighScore();

        // Set High Score Screen
        if (graphicRouter != null)
        {
            graphicRouter.HighScoreScreenClear();
        }
        
        StartGame(GameState.StartScreen);

        yield break;
    }

    private void TogglePause()
    {
        // Flip state ON -> OFF, OFF -> ON
        IsPaused = !IsPaused;

        Time.timeScale = IsPaused ? 0f : 1f;

        if(IsPaused)
        {
            if (graphicRouter != null)
            graphicRouter.PauseScreenSet();
        }
        else
        {
            if (graphicRouter != null)
            graphicRouter.PauseScreenClear();
        }

        Debug.Log(IsPaused ? "Game paused." : "Game resumed.");
    }

    private void UpdateHighScore()
    {
        highScore = HighScoreManager.GetHighScore();
        if (graphicRouter != null)
            graphicRouter.HighScore();
    }    

    // Elegant closing cleanup
    private void OnDestroy()
    {
        // Avoid leaving the editor or another scene paused.
        Time.timeScale = 1f;
    }
}

