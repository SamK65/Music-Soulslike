using UnityEngine;
using TMPro;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager Instance { get; private set; }

    [Header("Score Text")]
    [SerializeField] private TextMeshProUGUI uiText; 

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void ScoreUpdate(int score)
    {
        uiText.SetText($"{score}");
    }
}
