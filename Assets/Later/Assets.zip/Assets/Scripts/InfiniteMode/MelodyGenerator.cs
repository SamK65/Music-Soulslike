
using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class MelodyData
{
    public int startNote;
    public List<int> melody = new List<int>();
    public float noteLength;
    public float bpm;

    // Natural minor scale: degrees 1 through 7
    private static readonly int[] NaturalMinorOffsets =
        { 0, 2, 3, 5, 7, 8, 10 };

    // Convert melody intervals to MIDI notes
    public int GetMidiNote(int index)
    {
        if (index < 0 || index >= melody.Count)
            throw new ArgumentOutOfRangeException(nameof(index));

        int degree = melody[index];

        if (degree < 1 || degree > 7)
            throw new InvalidOperationException(
                "Melody degrees must be between 1 and 7.");

        return startNote + NaturalMinorOffsets[degree - 1];
    }
    // Convert degrees to minor scale degrees with startNote offset
    public int DegreeToMidi(int degree)
    {
        if (degree < 0 || degree > 7)
            throw new ArgumentOutOfRangeException(nameof(degree));

        return startNote + NaturalMinorOffsets[degree - 1];
    }

}

public class MelodyGenerator : MonoBehaviour
{
    public MelodyData Generate(int StartNote = -1, int BPM = 60, int melodyLength = 4)
    {
        int low = 4;
        int high = 4;

        // Select a tonic in the configured MIDI octave range
        int minimumMidi = low * 12;
        int maximumMidi = high * 12 + 11;
        
        if (StartNote == -1)
            StartNote = UnityEngine.Random.Range(minimumMidi, maximumMidi + 1);

        Debug.Log(
            $"minimumMidi: {minimumMidi}, maximumMidi: {maximumMidi}");

        MelodyData data = new MelodyData
        {
            startNote = StartNote,
            noteLength = 60.0f / BPM,
            bpm = BPM,
            melody = new List<int>()
        };

        for (int i = 0; i < melodyLength; i++)
        {
            int degree = UnityEngine.Random.Range(1, 8);
            data.melody.Add(degree);
        }

        Debug.Log(
            $"Generated melody: tonic MIDI {data.startNote}, " +
            $"degrees [{string.Join(", ", data.melody)}]");

        return data;
    }
}
