
using Unity.VisualScripting.FullSerializer;
using UnityEngine;

public class GraphicRouter : MonoBehaviour
{
    public static GraphicRouter Instance { get; private set; }

    [Header("Charachter Animators")]
    [SerializeField] private PlayerAnimation playerAnimation;
    [SerializeField] private BossAnimation bossAnimation;

    [Header("GUI Health Bars")]
    // Player Health Bar
    [SerializeField] private PlayerHealthBarManager playerHealth;
    // Boss Health Bar
    [SerializeField] private BossHealthBarManager bossHealth;

    [Header("GUI Score")]
    // Player Health Bar
    [SerializeField] private ScoreManager scoreManager;
    [SerializeField] private HighScoreGraphicManager highScoreGraphicManager;

    [Header("Round Card")]
    [SerializeField] private RoundCardManager roundCardManager;
    [Header("Screens")]
    [SerializeField] private IntroScreenManager introScreenManager;
    [SerializeField] private PauseScreenManager pauseScreenManager;
    [SerializeField] private VictoryScreenManager victoryScreenManager;
    [SerializeField] private DefeatScreenManager defeatScreenManager;
    [SerializeField] private HighScoreScreenManager highScoreScreenManager;


    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    ///// Global Graphics /////

    // Player Animations //
    public void PlayChallengeVictory()
    {

    }
    public void PlayPlayerDamage(float speed)
    {
        if (playerAnimation != null)
            playerAnimation.PlayerHit(speed);
    }
    public void PlayPlayerDefeat(bool active)
    {
        if (playerAnimation != null)
            playerAnimation.Death(active);
    }
    public void PlayParry(int degree, float speed)
    {
        if (playerAnimation != null)
            playerAnimation.PN(degree,speed);
    }
    public void PlayEarly() // TODO
    {

    }
    public void PlayPlayerVictory(bool active)
    {
        if (playerAnimation != null)
            playerAnimation.PlayPlayerVictory(active);
    }
    public void PlaySequenceOver(int count, float speed)
    {
        if (playerAnimation != null)
            playerAnimation.PlaySequenceOver(count, speed);
    }


    // Boss Animations //
    public void PlayBossChargeAttack(float chargeSpeed, float attackSpeed)
    {
        if (bossAnimation != null)
            bossAnimation.BossChargeAttack(chargeSpeed, attackSpeed);
    }
    public void PlayBossHit(float speed)
    {
        if (bossAnimation != null)
            bossAnimation.BossHit(speed);
    }
    public void PlayBossDeath(bool active)
    {
        if (bossAnimation != null)
            bossAnimation.BossDeath(active);
    }
    public void PlayBossWin(bool active)
    {
        if (bossAnimation != null)
            bossAnimation.BossWin(active);
    }


    // Health Bar Graphics //
    public void SetBossHealth(int health)
    {
        if (bossHealth != null)
            bossHealth.SetHealth(health);
    }
    public void SetBossMaxHealth(int maxHealth)
    {
        if (bossHealth != null)
            bossHealth.SetMaxHealth(maxHealth);
    }
    public void SetPlayerHealth(int health)
    {
        if (playerHealth != null)
            playerHealth.SetHealth(health);
    }
    public void SetPlayerMaxHealth(int maxHealth)
    {
        if (playerHealth != null)
            playerHealth.SetMaxHealth(maxHealth);
    }

    // Game Management //
    public void PlayClick()
    {
        
    }
    public void UpdateScore(int score)
    {
        if (scoreManager != null)
            scoreManager.ScoreUpdate(score);
    }
    public void HighScore()
    {
        if (highScoreGraphicManager != null)
            highScoreGraphicManager.HighScoreUpdate();
    }
    public void RoundCardSet(int boss, int round)
    {
        if (roundCardManager != null)
            roundCardManager.RoundCardSet(boss, round);
    }
    public void RoundCardClear()
    {
        if (roundCardManager != null)
            roundCardManager.RoundCardClear();
    }
    public void IntroScreenSet()
    {
        if (introScreenManager != null)
            introScreenManager.IntroScreenSet();
    }
    public void IntroScreenClear()
    {
        if (introScreenManager != null)
            introScreenManager.IntroScreenClear();
    }
    public void PauseScreenSet()
    {
        if (pauseScreenManager != null)
            pauseScreenManager.PauseScreenSet();
    }
    public void PauseScreenClear()
    {
        if (pauseScreenManager != null)
            pauseScreenManager.PauseScreenClear();
    }
    public void VictoryScreenSet()
    {
        if (victoryScreenManager != null)
            victoryScreenManager.VictoryScreenSet();
    }
    public void VictoryScreenClear()
    {
        if (victoryScreenManager != null)
            victoryScreenManager.VictoryScreenClear();
    }
    public void DefeatScreenSet()
    {
        if (defeatScreenManager != null)
            defeatScreenManager.DefeatScreenSet();
    }
    public void DefeatScreenClear()
    {
        if (defeatScreenManager != null)
            defeatScreenManager.DefeatScreenClear();
    }
    public void HighScoreScreenSet()
    {
        if (highScoreScreenManager != null)
            highScoreScreenManager.HighScoreScreenSet();
    }
    public void HighScoreScreenClear()
    {
        if (highScoreScreenManager != null)
            highScoreScreenManager.HighScoreScreenClear();
    }
    
}