
using System;
using System.Xml.Serialization;
using UnityEngine;
using UnityEngine.InputSystem;

public class VirtualKeyController : MonoBehaviour
{
    [Header("Highlight Keys")]
    [SerializeField] public GameObject Key1Highlight; 
    [SerializeField] public GameObject Key2Highlight; 
    [SerializeField] public GameObject Key3Highlight; 
    [SerializeField] public GameObject Key4Highlight; 
    [SerializeField] public GameObject Key5Highlight; 
    [SerializeField] public GameObject Key6Highlight; 
    [SerializeField] public GameObject Key7Highlight; 

    [Header("Pressed Keys")]
    [SerializeField] public GameObject Key1Trigger; 
    [SerializeField] public GameObject Key2Trigger; 
    [SerializeField] public GameObject Key3Trigger; 
    [SerializeField] public GameObject Key4Trigger; 
    [SerializeField] public GameObject Key5Trigger; 
    [SerializeField] public GameObject Key6Trigger; 
    [SerializeField] public GameObject Key7Trigger; 

    [Header("MIDI Input")]
    [Tooltip("MIDI note numbers corresponding to degrees 1-7.")]
    [SerializeField] private int[] midiNotes =
    {
        32, 33, 34, 35, 36, 37, 38
    };
    [SerializeField] private int midiQuit = 40;
    [SerializeField] private int midiEsc = 41;

    [Serializable] public class VirtualKeyState
    {
        public int degree;
        public bool pressed;
        public bool highlighted;
        public bool delta;
    }

    private enum InputSource
    {
        None,
        Keyboard,
        MIDI
    }

    private int activeKey = 0;
    private int activeMidiNote = -1;
    private InputSource activeSource = InputSource.None;

    public VirtualKeyState[] keys = new VirtualKeyState[7];

    public event Action<int> OnNotePressed;

    private readonly Key[] keyboardKeys =
    {
        Key.Digit1, Key.Digit2, Key.Digit3, Key.Digit4,
        Key.Digit5, Key.Digit6, Key.Digit7
    };

    private readonly Key[] numpadKeys =
    {
        Key.Numpad1, Key.Numpad2, Key.Numpad3, Key.Numpad4,
        Key.Numpad5, Key.Numpad6, Key.Numpad7
    };

    private void Awake()
    {
        for (int i = 0; i < keys.Length; i++)
        {
            keys[i] = new VirtualKeyState
            {
                degree = i + 1,
                pressed = false,
                highlighted = false
            };
        }
    }

    private void Update()
    {
        Keyboard keyboard = Keyboard.current;

        if (keyboard == null)
            return;

        // Check for Keyboard Esc and Quit
        if (keyboard.escapeKey.wasPressedThisFrame)
        {
            OnNotePressed?.Invoke(9);
        }
        else if (keyboard.zKey.wasPressedThisFrame)
        {
            OnNotePressed?.Invoke(8);
        }

        // MIDI currently owns input.
        if (activeSource == InputSource.MIDI)
            return;

        // Monitor release of the active keyboard key.
        if (activeSource == InputSource.Keyboard)
        {
            int i = activeKey - 1;

            bool up =
                keyboard[keyboardKeys[i]].wasReleasedThisFrame ||
                keyboard[numpadKeys[i]].wasReleasedThisFrame;

            if (up)
                ReleaseActiveKey();

            return;
        }

        // No active input. Check for a new keyboard press.
        for (int i = 0; i < 7; i++)
        {
            bool down =
                keyboard[keyboardKeys[i]].wasPressedThisFrame ||
                keyboard[numpadKeys[i]].wasPressedThisFrame;

            if (down)
            {
                activeSource = InputSource.Keyboard;
                activeKey = i + 1;

                PressKey(activeKey);

                return;
            }
        }
    }

    // MIDI NOTE ON
    public void OnMidiNoteOn(int midiNote, int velocity)
    {
        // Velocity zero is equivalent to Note Off.
        if (velocity <= 0)
        {
            OnMidiNoteOff(midiNote);
            return;
        }

        // Ignore MIDI if another input is active.
        if (activeSource != InputSource.None)
            return;

        // Find the corresponding virtual key.
        for (int i = 0; i < midiNotes.Length && i < 7; i++)
        {
            if (midiNotes[i] == midiNote)
            {
                activeSource = InputSource.MIDI;
                activeKey = i + 1;
                activeMidiNote = midiNote;

                PressKey(activeKey);

                return;
            }
        }
        if (midiEsc == midiNote)
        {
            OnNotePressed?.Invoke(9);
        }
        if (midiQuit == midiNote)
        {
            OnNotePressed?.Invoke(8);
        }
    }

    // MIDI NOTE OFF
    public void OnMidiNoteOff(int midiNote)
    {
        if (activeSource != InputSource.MIDI)
            return;

        // Only release the MIDI note currently holding input.
        if (midiNote != activeMidiNote)
            return;

        ReleaseActiveKey();
    }

    // Release MIDI input if the device disconnects.
    public void ReleaseMidiInput()
    {
        if (activeSource == InputSource.MIDI)
            ReleaseActiveKey();
    }

    // Shared key press logic.
    private void PressKey(int degree)
    {
        keys[degree - 1].pressed = true;

        SetKeyPressed(degree, true);

        OnNotePressed?.Invoke(degree);
    }

    // Shared key release logic.
    private void ReleaseActiveKey()
    {
        if (activeKey == 0)
            return;

        keys[activeKey - 1].pressed = false;

        SetKeyPressed(activeKey, false);

        activeKey = 0;
        activeMidiNote = -1;
        activeSource = InputSource.None;
    }
    private void SetKeyPressed(int degree, bool pressed)
    {
        switch (degree)
        {
            case 1: Key1Trigger.SetActive(pressed); break;
            case 2: Key2Trigger.SetActive(pressed); break;
            case 3: Key3Trigger.SetActive(pressed); break;
            case 4: Key4Trigger.SetActive(pressed); break;
            case 5: Key5Trigger.SetActive(pressed); break;
            case 6: Key6Trigger.SetActive(pressed); break;
            case 7: Key7Trigger.SetActive(pressed); break;
        }
    }

    public void SetHighlight(int degree, bool highlighted)
    {
        if (degree < 1 || degree > 7)
            return;

        keys[degree - 1].highlighted = highlighted;

        switch (degree)
        {
            case 1: Key1Highlight.SetActive(highlighted); break;
            case 2: Key2Highlight.SetActive(highlighted); break;
            case 3: Key3Highlight.SetActive(highlighted); break;
            case 4: Key4Highlight.SetActive(highlighted); break;
            case 5: Key5Highlight.SetActive(highlighted); break;
            case 6: Key6Highlight.SetActive(highlighted); break;
            case 7: Key7Highlight.SetActive(highlighted); break;
        }
    }

    public void ClearHighlights()
    {
        foreach (VirtualKeyState key in keys)
            key.highlighted = false;

        Key1Highlight.SetActive(false);
        Key2Highlight.SetActive(false);
        Key3Highlight.SetActive(false);
        Key4Highlight.SetActive(false);
        Key5Highlight.SetActive(false);
        Key6Highlight.SetActive(false);
        Key7Highlight.SetActive(false);
    }

    public VirtualKeyState GetKeyState(int degree)
    {
        if (degree < 1 || degree > 7)
            return null;

        return keys[degree - 1];
    }
}
