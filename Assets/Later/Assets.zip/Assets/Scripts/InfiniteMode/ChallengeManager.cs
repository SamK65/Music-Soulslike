
using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;

public class ChallengeManager : MonoBehaviour
{
    public enum ChallengeState
    {
        Idle,
        CallPhase,
        ResponsePhase,
        WaitingForNextNote,
        ChallengeVictory,
        GameOver,
        BossDefeated
    }

    [Header("References")]
    [SerializeField] private MelodyGenerator melodyGenerator;
    [SerializeField] private VirtualKeyController virtualKeys;
    [SerializeField] private PdMessageRouter pdRouter;
    [SerializeField] private GraphicRouter graphicRouter;

    [Header("Challenge Settings")]
    [SerializeField, Min(1)] private int bossHitsRequired = 3;
    [SerializeField, Min(0f)] private float delayBetweenChallenges = 0f;

    public ChallengeState CurrentState { get; private set; }
        = ChallengeState.Idle;

    public int BossHitsRemaining { get; private set; }
    public MelodyData CurrentMelody { get; private set; }
    public int CurrentNoteIndex { get; private set; }

    // Difficulty Controls
    private int BPM = 60;
    private int MelodyLength = 4;

    private float challengeClock;
    private float noteStartTime;
    private float windowStartTime;
    private float allowance;
    private bool noteResolved;
    private bool noteSucceeded;
    private bool clickResolved;
    private bool challengesStarted;
    private float punchSpeed;
    private float bossChargeSpeed;
    private float bossAttackSpeed;
    private float bossHitSpeed;
    private float playerSeqSpeed;
    private float hitSpeed;
    private int countMisses = 0;
    private int StartNote = -1;

    // Temporaries
    private int BPM_temp;
    private int MelodyLength_temp;


    private void Awake()
    {
        if (melodyGenerator == null)
            melodyGenerator = GetComponent<MelodyGenerator>();

        if (virtualKeys == null)
            virtualKeys = GetComponent<VirtualKeyController>();

        if (pdRouter == null)
            pdRouter = GetComponent<PdMessageRouter>();

        if (graphicRouter == null)
            graphicRouter = GetComponent<GraphicRouter>();
    }

    private void OnEnable()
    {
        if (virtualKeys != null)
            virtualKeys.OnNotePressed += HandlePlayerInput;
    }

    private void OnDisable()
    {
        if (virtualKeys != null)
            virtualKeys.OnNotePressed -= HandlePlayerInput;
    }

    public void CancelChallenges()
    {
        // Stop RunChallenge, RunResponseNote, and any other
        // coroutines running on this ChallengeManager.
        StopAllCoroutines();

        // Reset challenge state.
        challengesStarted = false;
        CurrentState = ChallengeState.Idle;

        // Clear keyboard highlights.
        if (virtualKeys != null)
            virtualKeys.ClearHighlights();

        Debug.Log("Challenge coroutines terminated.");
    }

    public IEnumerator StartChallenges()
    {
        // Wait for Challenge to be started
        if (challengesStarted)
            yield break;

        if (melodyGenerator == null || virtualKeys == null)
        {
            Debug.Log("ChallengeManager requires MelodyGenerator and VirtualKeys");
            yield break;
        } 

        challengesStarted = true;

        // Boss Health
        BossHitsRemaining = bossHitsRequired;

        if (graphicRouter != null)
        {
            // Initialize animation states
            graphicRouter.PlayPlayerDefeat(false);
            graphicRouter.PlayBossDeath(false);
            graphicRouter.PlayPlayerVictory(false);
            graphicRouter.PlayBossWin(false);

            // Initialize Health Bars
            graphicRouter.SetBossMaxHealth(bossHitsRequired);
            graphicRouter.SetPlayerMaxHealth(GameData.MaxHealth);

            // Set Health Bars
            graphicRouter.SetPlayerHealth(GameData.Health);
            graphicRouter.SetBossHealth(BossHitsRemaining);

            // Initialize Score
            graphicRouter.UpdateScore(GameData.Score);

            StartNote = -1;
        }

        // Set BPM and Melody Length
        SetDifficulty();

        // Start the first challenge
        BeginChallenge();

        // Wait until the boss dies or the player dies.
        yield return new WaitUntil(() =>
            CurrentState == ChallengeState.BossDefeated ||
            CurrentState == ChallengeState.GameOver ||
            !GameData.Active
        );

        challengesStarted = false;

        Debug.Log("Boss encounter completed.");
    }

    public void BeginChallenge()
    {
        if (GameData.Health <= 0 || BossHitsRemaining <= 0 || !GameData.Active)
            return;

        // Generate Melody
        CurrentMelody = melodyGenerator.Generate(StartNote, BPM, MelodyLength);
        StartNote = CurrentMelody.startNote;
        
        Debug.Log($"BPM: {BPM}, MelodyLength: {MelodyLength}");
        Debug.Log($"CurrentMelody: Startnote {CurrentMelody.startNote}, Melody: {CurrentMelody.melody}, NoteLength: {CurrentMelody.noteLength}, BPM: {CurrentMelody.bpm}");

        // Initialize:
        // Current Note
        CurrentNoteIndex = 0;
        // Clock
        challengeClock = 0f;
        //Misses
        countMisses = 0;
        // Current State of Challenge = Call Phase
        CurrentState = ChallengeState.CallPhase;
        // Remove any highlights
        virtualKeys.ClearHighlights();

        // Start the Challenge
        StartCoroutine(RunChallenge());
    }

    private IEnumerator RunChallenge()
    {
        if (graphicRouter != null)
            graphicRouter.RoundCardSet(GameData.Level[0], GameData.Level[1]);
        
        // Stop decay of player note
        if (pdRouter != null)
            pdRouter.PlayMidiNote(CurrentMelody.startNote,1,0);
        
        // Play tonic First Round
        // Start note, tone = boss
        if (BossHitsRemaining == bossHitsRequired)
        {
            if (pdRouter != null)
                pdRouter.PlayMidiNote(CurrentMelody.startNote,1,127);

            yield return new WaitForSeconds(CurrentMelody.noteLength);

            // End note
            if (pdRouter != null)
                pdRouter.StopMidiNote(CurrentMelody.startNote,1);

            yield return new WaitForSeconds(CurrentMelody.noteLength);
        }
        
        if (graphicRouter != null)
            graphicRouter.RoundCardClear();

        // Melody Sequence

        // Mark starting note with highlight
        virtualKeys.SetHighlight(CurrentMelody.melody[0], true);
        
        Debug.Log($"CURENTMELODY COUNT = {CurrentMelody.melody.Count}");

        if (bossHitsRequired != BossHitsRemaining)
        {
            bossChargeSpeed = 10.16f / (CurrentMelody.noteLength * (CurrentMelody.melody.Count - 2.0f));
        }
        else
        {
            bossChargeSpeed = 10.16f / (CurrentMelody.noteLength * (CurrentMelody.melody.Count - 1.0f));
        }
        bossAttackSpeed = 3.3f / (CurrentMelody.noteLength * 2f);
        bossHitSpeed = 1.333f / (CurrentMelody.noteLength * 1f);

        if (graphicRouter != null)
            graphicRouter.PlayBossChargeAttack(bossChargeSpeed, bossAttackSpeed);

        // CALL: the boss plays the complete melody.
        for (int i = 0; i < CurrentMelody.melody.Count; i++)
        {
            int degree = CurrentMelody.melody[i];
            int midiNote = CurrentMelody.GetMidiNote(i);
            
            // Click
            if (pdRouter != null)
                pdRouter.PlayClick();
            if (graphicRouter != null)
                graphicRouter.PlayClick();
            // Start note, tone = boss
            if (pdRouter != null)
                pdRouter.PlayMidiNote(midiNote,1,127);
            
            if (i == CurrentMelody.melody.Count - 1)
            {
                yield return new WaitForSeconds(CurrentMelody.noteLength * 0.5f);
            }
            else
            {
                yield return new WaitForSeconds(CurrentMelody.noteLength);
            }

            // End note
            if (pdRouter != null)
                pdRouter.StopMidiNote(midiNote,1);
        }

        /*
        // Count in start
        for (int i = 0; i < 3; i++)
        {
            if (pdRouter != null)
                pdRouter.PlayClick();
            if (graphicRouter != null)
                graphicRouter.PlayClick();

            yield return new WaitForSeconds(
                CurrentMelody.noteLength);
        }
        if (pdRouter != null)
            pdRouter.PlayClick();
        if (graphicRouter != null)
            graphicRouter.PlayClick();
        */

        /*
        yield return new WaitForSeconds(
            CurrentMelody.noteLength * 0.5f);
        */

        // Count in ends half a beat beat after last click
        // This accounts for the half beat before time X

        // Clear highlight from starting note
        virtualKeys.SetHighlight(CurrentMelody.melody[0], false);

        virtualKeys.ClearHighlights();

        // Start a fresh clock for the response.
        challengeClock = 0f;
        CurrentState = ChallengeState.ResponsePhase;

        // RESPONSE: the player reproduces the melody.
        for (int i = 0; i < CurrentMelody.melody.Count; i++)
        {
            CurrentNoteIndex = i;

            yield return StartCoroutine(
                RunResponseNote(i));

            if (CurrentState == ChallengeState.GameOver)
                yield break;
        }

        if (GameData.Health <= 0 || BossHitsRemaining <= 0)
        {
            CurrentState = ChallengeState.GameOver;
            BeginChallenge();
        }

        // Every note was resolved and the player survived.
        CurrentState = ChallengeState.ChallengeVictory;

        // Handle Boss Hit
        BossHitsRemaining--;

        // Increment Difficulty every round
        GameData.Difficulty++;

        SetDifficulty();

        Debug.Log($"BPM: {BPM}, MelodyLength: {MelodyLength}");

        // update boss health bar
        if (graphicRouter != null)
            graphicRouter.SetBossHealth(BossHitsRemaining);

        if (pdRouter != null)
        {
            pdRouter.PlayBossHit();
            pdRouter.PlayChallengeVictory();
        }
        if (graphicRouter != null)
        {
            graphicRouter.PlayBossHit(bossHitSpeed);
            graphicRouter.PlayChallengeVictory();
        }

        Debug.Log(
            $"Challenge cleared! Boss hits remaining: " +
            $"{BossHitsRemaining}");

        if (countMisses == 0 && GameData.Health < GameData.MaxHealth)
        {
            GameData.Health++;
            // update player health bar
            if (graphicRouter != null)
                graphicRouter.SetPlayerHealth(GameData.Health);

            Debug.Log("Perfect!, Health++ ");
        }

        if (BossHitsRemaining <= 0)
        {
            Debug.Log("Boss defeated!");

            if (pdRouter != null)
            {
                pdRouter.PlayBossDeath();
                pdRouter.PlayPlayerVictory();
            }
            if (graphicRouter != null)
            {
                graphicRouter.PlayBossDeath(true);
                graphicRouter.PlayPlayerVictory(true);
            }

            GameData.Level[0] += 1;

            CurrentState = ChallengeState.BossDefeated;
            yield break;
        }

        GetDifficulty();

        Debug.Log($"Next BPM: {BPM_temp}, Next MelodyLength_temp: {MelodyLength_temp}");

        playerSeqSpeed = 6.0f / (MelodyLength_temp * (60.0f / BPM_temp));

        if (graphicRouter != null)
            graphicRouter.PlaySequenceOver(countMisses, playerSeqSpeed);

        // Break time between challenges
        yield return new WaitForSeconds(delayBetweenChallenges);

        BeginChallenge();
    }

    // Coroutine handling clocks and windows in the background
    private IEnumerator RunResponseNote(int index)
    {
        CurrentState = ChallengeState.ResponsePhase;

        float length = CurrentMelody.noteLength;

        // set animation speeds
        punchSpeed = 1 / (length * 0.6f);
        hitSpeed = 1 / (length * 0.2f);

        // clock reference of 0
        noteStartTime = challengeClock;
        // x (describes real timing, not just offset)
        windowStartTime = noteStartTime + length / 2f;
        // a
        allowance = length / 2f;

        // Marks regardless of failed or succeeded if the note is still answerable 
        noteResolved = false;
        // Marks if the note was answered correctly
        noteSucceeded = false;
        // Marks if click has occured
        clickResolved = false;

        // A note can only be answered within its allotted length.
        while (challengeClock - noteStartTime < length)
        {
            challengeClock += Time.deltaTime;

            if (!clickResolved && challengeClock > windowStartTime)
            {
                if (pdRouter != null)
                    pdRouter.PlayClick();
                clickResolved = true;
            }

            // The deadline shrinks with every mistake. (x + a)
            float deadline = windowStartTime + allowance;

            // if note not answered yet and clock > x + a, note failed -> player takes damage
            if (!noteResolved && challengeClock > deadline)
            {
                noteResolved = true;
                noteSucceeded = false;

                GameData.Health--;

                // update player health bar
                if (graphicRouter != null)
                    graphicRouter.SetPlayerHealth(GameData.Health);

                Debug.Log(
                    $"Missed degree {CurrentMelody.melody[index]}. " +
                    $"Health: {GameData.Health}");

                countMisses += 1;

                if (pdRouter != null)
                    pdRouter.PlayPlayerDamage();
                if (graphicRouter != null)
                    graphicRouter.PlayPlayerDamage(hitSpeed);
                

                // if player is dead, game over
                if (GameData.Health <= 0)
                {
                    GameData.Health = 0;

                    Debug.Log("Game over!");

                    if (pdRouter != null)
                        pdRouter.PlayPlayerDefeat();
                    if (graphicRouter != null)
                        graphicRouter.PlayPlayerDefeat(true);

                    if (graphicRouter != null)
                        graphicRouter.PlayBossWin(true);

                    CurrentState = ChallengeState.GameOver;
                    yield break;
                }
            }

            yield return null;
        }

        // Both successful and failed notes occupy their full length.
        CurrentState = ChallengeState.WaitingForNextNote;
    }

    private void HandlePlayerInput(int degree)
    {
        if (CurrentState != ChallengeState.ResponsePhase)
            return;

        if (noteResolved)
            return;

        float length = CurrentMelody.noteLength;
        float deadline = windowStartTime + allowance;

        // The note window has expired; the coroutine will
        // register the miss and apply damage.
        if (challengeClock > deadline)
            return;

        bool correctDegree =
            degree == CurrentMelody.melody[CurrentNoteIndex];

        bool insideWindow =
            challengeClock >= windowStartTime - allowance;

        if (correctDegree && insideWindow)
        {
            noteResolved = true;
            noteSucceeded = true;

            GameData.Score += 10;

            if (graphicRouter != null)
                graphicRouter.UpdateScore(GameData.Score);

            int midiNote = CurrentMelody.GetMidiNote(CurrentNoteIndex);

            if (pdRouter != null)
            {
                pdRouter.PlayMidiNote(midiNote, 0, 127);
                pdRouter.PlayParry();
            }

            if (graphicRouter != null)
                graphicRouter.PlayParry(degree, punchSpeed);

            Debug.Log(
                $"Correct! Degree {degree}. " +
                $"Score: {GameData.Score}");

            return;
        }

        if (!correctDegree)
        {
            if (pdRouter != null)
            {
                int midiNote = CurrentMelody.DegreeToMidi(degree);

                pdRouter.PlayMidiNote(midiNote, 2, 30);
                pdRouter.PlayParry();
            }
        }

        // if Early, make early noise
        if (!insideWindow)
        {
            if (pdRouter != null)
                pdRouter.PlayEarly();
            if (graphicRouter != null)
                graphicRouter.PlayEarly();
            
        }

        // Wrong note or input before the valid window.
        allowance -= length / 8f;

        Debug.Log(
            $"Incorrect/early input: {degree}. " +
            $"Remaining allowance: {allowance:F3}s");
    }

    private void SetDifficulty()
    {
        GetDifficulty();
        
        BPM = BPM_temp;
        MelodyLength = MelodyLength_temp;
    }

    private void GetDifficulty(int shift = 0)
    {
        if (GameData.Difficulty < 0)
        {
            GameData.Difficulty = 0;
        }

        int Diff = GameData.Difficulty + shift;

        if (Diff < 8)
        {
            BPM_temp = 60 + (Diff * 5);
            MelodyLength_temp = 4;
        }
        else if (Diff <= 12 && Diff >= 8)
        {
            BPM_temp = 100;
            MelodyLength_temp = Diff - 4;
        }
        else if (Diff > 12)
        {
            BPM_temp = 40 + (Diff * 5);
            MelodyLength_temp = 8;
        }
    }

}
