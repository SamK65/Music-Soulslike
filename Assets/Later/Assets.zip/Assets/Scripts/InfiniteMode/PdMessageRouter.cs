
using UnityEngine;
using extOSC;
using UnityEngine.Rendering.Universal;
using System.Net.Sockets;

public class PdMessageRouter : MonoBehaviour
{
    
    [Header("References")]
    public OSCTransmitter transmitter;
    
    private string address;

    public static PdMessageRouter Instance { get; private set; }
    
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    // player: tone = 0, boss: tone = 1, player: miss = 2
    public void PlayMidiNote(int midiNote,int tone = 0 ,int velocity = 100)
    {
        if (transmitter == null)
		{
			Debug.LogWarning("OSC transmitter is not assigned.");
			return;
		}

        // Set address
        if (tone == 0)
        {
            address = "Player";
        }
        else if (tone == 1)
        {
            address = "Boss";
        }
        else
        {
            address = "Miss";
        }

        OSCMessage message = new OSCMessage($"/{address}/Instrument/");

        message.AddValue(OSCValue.Int(midiNote));   // MIDI note
        message.AddValue(OSCValue.Int(velocity));   // Velocity

        transmitter.Send(message);

        Debug.Log($"Sent MIDI note number {midiNote} to Pd.");
    }

    public void StopMidiNote(int midiNote,int tone = 0)
    {
        CheckActivity();

        // Set address
        if (tone == 0)
        {
            address = "Player";
        }
        else if (tone == 1)
        {
            address = "Boss";
        }
        else
        {
            address = "Miss";
        }

        OSCMessage message = new OSCMessage($"/{address}/Instrument/");
        message.AddValue(OSCValue.Int(midiNote));   // MIDI note
        message.AddValue(OSCValue.Int(0));          // Velocity
        transmitter.Send(message);

        Debug.Log($"[PD placeholder] Stop note {midiNote}");
    }
    public void PlayBossHit()
    {
        CheckActivity();
        OSCMessage message = new OSCMessage("/Hit");
        transmitter.Send(message);
        Debug.Log("[PD placeholder] Boss hit event");
    }
    public void PlayPlayerDamage()
    {
        CheckActivity();
        OSCMessage message = new OSCMessage("/Damage");
        transmitter.Send(message);
        Debug.Log("[PD placeholder] Player damage event");
    }

    public void PlayParry()
    {
        Debug.Log("[PD placeholder] Successful parry event");
    }

    public void PlayChallengeVictory()
    {
        CheckActivity();
        OSCMessage message = new OSCMessage("/Victory");
        transmitter.Send(message);
        Debug.Log("[PD placeholder] Challenge victory event");
    }

    public void PlayPlayerDefeat()
    {
        Debug.Log("[PD placeholder] Player defeat event");
    }

    public void PlayClick()
    {
        CheckActivity();
        OSCMessage message = new OSCMessage("/Click");
        transmitter.Send(message);
        Debug.Log("[PD placeholder] Click event");
    }

    public void PlayEarly()
    {
        Debug.Log("[PD placeholder] Early event");
    }

    public void PlayBossDeath() // TODO
    {
        CheckActivity();
        OSCMessage message = new OSCMessage("/BossDeath");
        transmitter.Send(message);
        Debug.Log("[PD placeholder] Click event");
    }
    public void PlayPlayerVictory() // TODO
    {
        CheckActivity();
        OSCMessage message = new OSCMessage("/PlayerVictory");
        transmitter.Send(message);
        Debug.Log("[PD placeholder] Click event");
    }

    private void CheckActivity()
    {
        if (transmitter == null)
		{
			Debug.LogWarning("OSC transmitter is not assigned.");
			return;
		}
    }
}
