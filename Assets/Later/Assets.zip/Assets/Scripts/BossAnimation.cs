using UnityEngine;

public class BossAnimation : MonoBehaviour
{
    public static BossAnimation Instance { get; private set; }

    [SerializeField] private Animator animator;
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        animator = GetComponent<Animator>();
    }

    public void BossHit(float speed)
    {
        animator.SetFloat("BossHitSpeed", speed);
        animator.SetTrigger("BossHit");
        Debug.Log("Animation BossHit played.");
    }

    public void BossChargeAttack(float chargeSpeed, float attackSpeed)
    {
        animator.SetFloat("SeqLengthMultiplier", chargeSpeed);
        animator.SetFloat("SetAttackMultiplier", attackSpeed);
        animator.SetTrigger("BossCharge");
    }

    public void BossDeath(bool active)
    {
        animator.SetBool("BossDeath", active);
        Debug.Log($"Animation BossDeath toggled {active}.");
    }

    public void BossWin(bool active)
    {
        animator.SetBool("BossWin", active);
        Debug.Log($"Animation BossWin toggled {active}.");
    }
}
