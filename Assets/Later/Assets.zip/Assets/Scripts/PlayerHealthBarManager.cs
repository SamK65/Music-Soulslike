using UnityEngine;
using UnityEngine.UI;

public class PlayerHealthBarManager : MonoBehaviour
{
    public static PlayerHealthBarManager Instance { get; private set; }

    [Header("Health Bar")]
    [SerializeField] private Slider healthSlider; 

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void SetMaxHealth(int maxHealth)
    {
        healthSlider.maxValue = maxHealth;
        healthSlider.value = maxHealth;
    }

    public void SetHealth(int newHealth)
    {
        healthSlider.value = newHealth;
    }




}
