using System.ComponentModel.Design;
using UnityEngine;

public class PlayerAnimation : MonoBehaviour
{
    public static PlayerAnimation Instance { get; private set; }
    [SerializeField] private Animator animator;
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        animator = GetComponent<Animator>();
    }

    // SPEEEED //
    public void PN(int degree, float speed)
    {
        animator.SetFloat("PunchSpeed", speed);
        animator.SetTrigger($"PN{degree}");
        Debug.Log("Animation PN1 played.");
    }
    public void PlayerHit(float speed)
    {
        animator.SetFloat("HitSpeed", speed);
        animator.SetBool("PlayerHit", true);
        Debug.Log("Animation PlayerHit played.");
    }
    // BOOOOLS //
    public void Death(bool active)
    {
        animator.SetBool("PlayerDead", active);
        Debug.Log("Animation Death played.");
    }
    public void PlayBossDeath(bool active) // TODO
    {
        animator.SetBool("BossDead", active);
        Debug.Log("Animation BossDead played.");
    }
    public void PlayPlayerVictory(bool active) // TODO
    {
        animator.SetBool("PlayerWin", active);
        Debug.Log("Animation PlayerVictory played.");
    }
    // Counted Animations //    
    public void PlaySequenceOver(int count, float speed) // TODO
    {
        animator.SetFloat("SeqSpeed", speed);
        animator.SetInteger("SeqHits", count);
        animator.SetTrigger($"SeqOver");
        Debug.Log("Animation SeqOver played.");
    }
}
