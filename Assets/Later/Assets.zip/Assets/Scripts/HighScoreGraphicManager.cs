using UnityEngine;
using TMPro;

public class HighScoreGraphicManager : MonoBehaviour
{
    public static HighScoreGraphicManager Instance { get; private set; }

    [Header("High Score Text")]
    [SerializeField] private TextMeshProUGUI uiText; 

    private HighScoreManager.HighScoreEntry highScore;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void HighScoreUpdate()
    {
        highScore = HighScoreManager.GetHighScore();
        uiText.SetText($"{highScore.initials}\n{highScore.score}");
    }
}
