
using UnityEngine;

public class VisualPlayerController : MonoBehaviour
{
    [Header("Boss Reference")]
    public VisualBossController bossController;

    // PLAYER DEFLECT ANIMATION EVENT.
    public void PlayerDeflectOrbs()
    {
        if (bossController == null)
        {
            Debug.LogWarning("Boss controller reference is missing!", this);
            return;
        }

        bool orbDeflected = bossController.DeflectNearestOrb();

        if (!orbDeflected)
        {
            Debug.Log("No incoming orb available to deflect.");
        }
    }

    // PLAYER HIT ANIMATION EVENT.
    public void PlayerHitByOrb()
    {
        if (bossController == null)
        {
            Debug.LogWarning("Boss controller reference is missing!", this);
            return;
        }

        bool orbExploded = bossController.ExplodeNearestOrb();

        if (!orbExploded)
        {
            Debug.Log("No incoming orb available to explode.");
        }
    }

    // PLAYER DEATH ANIMATION EVENT.
    public void PlayerDeathCleanup()
    {
        if (bossController == null)
        {
            Debug.LogWarning("Boss controller reference is missing!", this);
            return;
        }

        bossController.ClearRemainingOrbs();
    }
}
