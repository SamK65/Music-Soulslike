Shader "Custom/URP_HandDrawnOutline"
{
    Properties
    {
        [MainColor] _Color ("Main Color", Color) = (1,1,1,1)
        _OutlineColor ("Outline Color", Color) = (0,0,0,1)
        _OutlineThickness ("Outline Thickness", Range(0.0, 0.1)) = 0.02
        _BoilSpeed ("Boil Speed", Range(0.0, 30.0)) = 12.0
        _BoilScale ("Boil Wobble Scale", Range(0.0, 0.05)) = 0.005
    }
    
    SubShader
    {
        Tags { "RenderPipeline" = "UniversalPipeline" "RenderType"="Opaque" "Queue"="Geometry" }
        LOD 100

        // ==========================================
        // PASS 1: THE INVERTED HULL OUTLINE
        // ==========================================
        Pass
        {
            Name "Outline"
            Tags { "LightMode" = "SRPDefaultUnlit" }
            Cull Front
            ZWrite On

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            struct Attributes
            {
                float4 positionOS   : POSITION;
                float3 normalOS     : NORMAL;
            };

            struct Varyings
            {
                float4 positionCS   : SV_POSITION;
            };

            float4 _OutlineColor;
            float _OutlineThickness;
            float _BoilSpeed;
            float _BoilScale;

            Varyings vert(Attributes input)
            {
                Varyings output;
                
                // Calculate choppy stepped time for the hand-drawn boil effect
                float steppedTime = floor(_Time.y * _BoilSpeed);
                
                // Compute a wavy noise offset based on vertex position and time
                float wobble = sin(input.positionOS.x * 10.0 + steppedTime) * 
                               cos(input.positionOS.y * 10.0 + steppedTime) * 
                               sin(input.positionOS.z * 10.0 + steppedTime);

                // Displace vertices outward along their local normals
                float3 extrudedPos = input.positionOS.xyz + input.normalOS * (_OutlineThickness + wobble * _BoilScale);
                
                output.positionCS = TransformObjectToHClip(extrudedPos);
                return output;
            }

            half4 frag(Varyings input) : SV_Target
            {
                return half4(_OutlineColor.rgb, 1.0);
            }
            ENDHLSL
        }

        // ==========================================
        // PASS 2: SIMPLE CHARACTER BASE SURFACE
        // ==========================================
        Pass
        {
            Name "Base"
            Tags { "LightMode" = "UniversalForward" }
            Cull Back
            ZWrite On

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"

            struct Attributes
            {
                float4 positionOS   : POSITION;
                float3 normalOS     : NORMAL;
            };

            struct Varyings
            {
                float4 positionCS   : SV_POSITION;
                float3 normalWS     : TEXCOORD0;
            };

            half4 _Color;

            Varyings vert(Attributes input)
            {
                Varyings output;
                output.positionCS = TransformObjectToHClip(input.positionOS.xyz);
                output.normalWS = TransformObjectToWorldNormal(input.normalOS);
                return output;
            }

            half4 frag(Varyings input) : SV_Target
            {
                // Simple diffuse lighting fallback calculation
                float3 normalWS = normalize(input.normalWS);
                Light mainLight = GetMainLight();
                half lightIntensity = saturate(dot(normalWS, mainLight.direction));
                
                return half4(_Color.rgb * (lightIntensity * 0.5 + 0.5), 1.0);
            }
            ENDHLSL
        }
    }
}
